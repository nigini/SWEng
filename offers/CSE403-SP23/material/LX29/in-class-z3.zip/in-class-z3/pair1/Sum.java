
public class Sum {
    /**
     * sum(int x, int y, int z) computes the sum of x + y + a
     */
    public int sum(int x, int y, int z){
        int a1 = x + y;
        int a2 = a1 + z;
        return a2;
    }

}
